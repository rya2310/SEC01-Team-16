document.getElementById('chatForm').addEventListener('submit', function(e) {
    e.preventDefault();
    const userInput = document.getElementById('userInput').value;

    // Display user message
    displayMessage(userInput, 'user-message');
    document.getElementById('userInput').value = '';

    // Send message to the backend and handle response
    fetch('/api/chatbot', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ message: userInput })
    })
    .then(response => response.json())
    .then(data => displayMessage(data.reply, 'bot-message'))
    .catch(error => console.error('Error:', error));
});

function displayMessage(text, className) {
    const chatBox = document.getElementById('chatBox');
    const messageElement = document.createElement('div');
    messageElement.classList.add('message', className);
    messageElement.innerText = text;
    chatBox.appendChild(messageElement);
    chatBox.scrollTop = chatBox.scrollHeight;
}
